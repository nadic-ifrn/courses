import styled from "styled-components/native";

export const StyledText = styled.Text`
  font-size: 36px;
  line-height: 44px;
  font-weight: bold;
  color: #2d767f;
`;
