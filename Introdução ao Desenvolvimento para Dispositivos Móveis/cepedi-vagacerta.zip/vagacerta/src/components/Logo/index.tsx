import { StyledText } from "./styles";

export function Logo() {
  return <StyledText>VagaCerta</StyledText>;
}
