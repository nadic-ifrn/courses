import { StyledText } from "./styles";

export function Title() {
  return <StyledText>Tarefas em aberto:</StyledText>;
}
