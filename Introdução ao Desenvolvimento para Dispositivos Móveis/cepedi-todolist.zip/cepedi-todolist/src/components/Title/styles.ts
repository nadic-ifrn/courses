import styled from "styled-components/native";

export const StyledText = styled.Text`
  font-size: 24px;
  color: #ffffff;
  align-self: flex-start;
`;
