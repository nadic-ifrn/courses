import { Text, TouchableOpacity } from "react-native";

export function Button() {
  return (
    <TouchableOpacity>
      <Text>Adicionar</Text>
    </TouchableOpacity>
  );
}
